/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referring to this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'OptiSoft-OMR-Circled-Symbols\'">' + entity + '</span>' + html;
	}
	var icons = {
		'circled-sym-circled-0n': '&#x30;',
		'circled-sym-circled-1n': '&#x31;',
		'circled-sym-circled-2n': '&#x32;',
		'circled-sym-circled-3n': '&#x33;',
		'circled-sym-circled-4n': '&#x34;',
		'circled-sym-circled-5n': '&#x35;',
		'circled-sym-circled-6n': '&#x36;',
		'circled-sym-circled-7n': '&#x37;',
		'circled-sym-circled-8n': '&#x38;',
		'circled-sym-circled-9n': '&#x39;',
		'circled-sym-circled-An': '&#x41;',
		'circled-sym-circled-Bn': '&#x42;',
		'circled-sym-circled-Cn': '&#x43;',
		'circled-sym-circled-Dn': '&#x44;',
		'circled-sym-circled-En': '&#x45;',
		'circled-sym-circled-Fn': '&#x46;',
		'circled-sym-circled-Gn': '&#x47;',
		'circled-sym-circled-Hn': '&#x48;',
		'circled-sym-circled-In': '&#x49;',
		'circled-sym-circled-Jn': '&#x4a;',
		'circled-sym-circled-Kn': '&#x4b;',
		'circled-sym-circled-Ln': '&#x4c;',
		'circled-sym-circled-Mn': '&#x4d;',
		'circled-sym-circled-Nn': '&#x4e;',
		'circled-sym-circled-On': '&#x4f;',
		'circled-sym-circled-Pn': '&#x50;',
		'circled-sym-circled-Qn': '&#x51;',
		'circled-sym-circled-Rn': '&#x52;',
		'circled-sym-circled-Sn': '&#x53;',
		'circled-sym-circled-Tn': '&#x54;',
		'circled-sym-circled-Un': '&#x55;',
		'circled-sym-circled-Vn': '&#x56;',
		'circled-sym-circled-Wn': '&#x57;',
		'circled-sym-circled-Xn': '&#x58;',
		'circled-sym-circled-Yn': '&#x59;',
		'circled-sym-circled-Zn': '&#x5a;',
		'circled-sym-circled-Ntilden': '&#xd1;',
		'circled-sym-circled-checkn': '&#x20dd;',
		'circled-sym-circled-ballotn': '&#x2713;',
		'circled-sym-circled-blankn': '&#xe001;',
		'circled-sym-circled-filledn': '&#xe002;',
		'circled-sym-circled-objectn': '&#xfffc;',
		'circled-sym-circled-unknownn': '&#xfffd;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/circled-sym-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
