/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referring to this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'Circled-Symbols\'">' + entity + '</span>' + html;
	}
	var icons = {
		'circled-sym-0': '&#x30;',
		'circled-sym-1': '&#x31;',
		'circled-sym-2': '&#x32;',
		'circled-sym-3': '&#x33;',
		'circled-sym-4': '&#x34;',
		'circled-sym-5': '&#x35;',
		'circled-sym-6': '&#x36;',
		'circled-sym-7': '&#x37;',
		'circled-sym-8': '&#x38;',
		'circled-sym-9': '&#x39;',
		'circled-sym-blank': '&#x20dd;',
		'circled-sym-filled': '&#xe801;',
		'circled-sym-check': '&#x2713;',
		'circled-sym-select': '&#x2717;',
		'circled-sym-A': '&#x41;',
		'circled-sym-B': '&#x42;',
		'circled-sym-C': '&#x43;',
		'circled-sym-D': '&#x44;',
		'circled-sym-E': '&#x45;',
		'circled-sym-F': '&#x46;',
		'circled-sym-G': '&#x47;',
		'circled-sym-H': '&#x48;',
		'circled-sym-I': '&#x49;',
		'circled-sym-J': '&#x4a;',
		'circled-sym-K': '&#x4b;',
		'circled-sym-L': '&#x4c;',
		'circled-sym-M': '&#x4d;',
		'circled-sym-N': '&#x4e;',
		'circled-sym-Ntilde': '&#xd1;',
		'circled-sym-O': '&#x4f;',
		'circled-sym-P': '&#x50;',
		'circled-sym-Q': '&#x51;',
		'circled-sym-R': '&#x52;',
		'circled-sym-S': '&#x53;',
		'circled-sym-T': '&#x54;',
		'circled-sym-U': '&#x55;',
		'circled-sym-V': '&#x56;',
		'circled-sym-W': '&#x57;',
		'circled-sym-X': '&#x58;',
		'circled-sym-Y': '&#x59;',
		'circled-sym-Z': '&#x5a;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/circled-sym-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
